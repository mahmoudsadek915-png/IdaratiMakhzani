تطبيق إدارة مخزني - مشروع أندرويد

هذا مشروع Android Studio يفتح برنامج إدارة المخزون داخل تطبيق أندرويد مستقل (WebView).
لم يتم إنتاج ملف APK هنا لأن بيئة الإنشاء الحالية لا تحتوي على Android SDK أو Gradle.

طريقة إنشاء APK:
1) فك ضغط الملف.
2) افتح مجلد IdaratiMakhzani في Android Studio.
3) انتظر مزامنة Gradle وتثبيت Android SDK 35 عند الطلب.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف غالباً في:
   app/build/outputs/apk/debug/app-debug.apk

يمكن أيضاً رفع المشروع إلى مستودع GitHub وتشغيل GitHub Actions من تبويب Actions
(الملف android.yml مرفق)، ثم تنزيل artifact باسم idarati-makhzani-debug-apk.

تنبيه: بيانات البرنامج محفوظة محلياً داخل مساحة WebView على الجهاز. احتفظ بنسخ احتياطية
من داخل التطبيق قبل حذف التطبيق أو بياناته أو تغيير الهاتف.
